from setuptools import setup, find_packages

setup(
    name="team11_project",
    version="0.2",
    packages=find_packages(),
)
